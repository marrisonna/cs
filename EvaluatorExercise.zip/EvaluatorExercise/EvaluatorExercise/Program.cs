﻿using System;
using System.IO;

namespace EvaluatorExercise
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                string pathToInput = Path.Combine(Directory.GetCurrentDirectory(), "inputTest8.txt");

                InstructionSet inputInstructions = new InstructionSet(pathToInput);

                System.Diagnostics.Stopwatch clock = new System.Diagnostics.Stopwatch();
                clock.Start();

                double result = inputInstructions.Result;

                clock.Stop();

                Console.WriteLine("The answer is " + result);

                Console.WriteLine("");

                Console.WriteLine("Time taken was " + clock.ElapsedMilliseconds / 1000.0 + " seconds");

            }
            catch (Exception err)
            {
                Console.WriteLine("An error occurred...");

                Console.WriteLine(err.Message);

                if (err.InnerException != null)
                    Console.WriteLine("  - " + err.InnerException.Message);


            }

            Console.WriteLine("");

            Console.WriteLine("Press any key to finish");

            Console.ReadKey();
        }
    }
}
