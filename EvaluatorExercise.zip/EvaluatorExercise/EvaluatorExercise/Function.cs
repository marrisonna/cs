﻿using System;
using System.Collections.Generic;

namespace EvaluatorExercise
{

    abstract class Function
    {
        public Function(int label, List<int> paramters, InstructionSet parentInstructionSet)
        {
            m_parentInstructionSet = parentInstructionSet;
            m_parameters = paramters;
            Label = label;
        }

        public int Label { get; private set; }

        public double Result
        {
            get
            {
                if (!m_cachedResult.HasValue)
                {
                    m_parentInstructionSet.CheckLabelForInfiniteLoop(Label);

                    m_cachedResult = Evaluate();

                    m_parentInstructionSet.ClearInfiniteLoopCheck(Label); 
                }
                return m_cachedResult.Value;
            }
        }

        abstract protected double Evaluate();

             

        ////////////////

        protected InstructionSet m_parentInstructionSet;

        protected List<int> m_parameters;

        protected double? m_cachedResult = null;
    }
}
