﻿using System;
using System.Collections.Generic;

namespace EvaluatorExercise
{
    class FunctionValue : Function
    {
        public FunctionValue(int label, List<int> paramters, InstructionSet parentInstructionSet) :
            base(label, paramters, parentInstructionSet)
        {
            if (paramters.Count > 1)
                throw new Exception("Multiple instructions have been specified using the  label '" + label + "'");
        }


        override protected double Evaluate()
        {
            return m_parameters[0];
        }

    }
}
