﻿using System;
using System.Collections.Generic;

namespace EvaluatorExercise
{
    class FunctionMultiply : Function
    {
        public FunctionMultiply(int label, List<int> paramters, InstructionSet parentInstructionSet) :
            base(label, paramters, parentInstructionSet)
        { }

        override protected double Evaluate()
        {
            double result = 1;

            foreach (int label in m_parameters)
            {
                Function currentFunction = m_parentInstructionSet.GetFunctionFromLabel(label);
                result *= currentFunction.Result;
            }

            return result;
        }
    }
}
