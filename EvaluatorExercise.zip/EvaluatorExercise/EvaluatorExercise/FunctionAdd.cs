﻿using System;
using System.Collections.Generic;

namespace EvaluatorExercise
{
    class FunctionAdd : Function
    {
        public FunctionAdd(int label, List<int> paramters, InstructionSet parentInstructionSet) :
            base(label, paramters, parentInstructionSet)
        { }


        override protected double Evaluate()
        {
            double result = 0;

            foreach (int label in m_parameters)
            {
                Function currentFunction = m_parentInstructionSet.GetFunctionFromLabel(label);
                result += currentFunction.Result;
            }

            return result;
        }
    }
}
