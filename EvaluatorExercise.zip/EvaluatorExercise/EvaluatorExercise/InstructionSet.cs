﻿using System;
using System.IO;
using System.Text;
using System.Collections.Generic;
using System.Linq;


namespace EvaluatorExercise
{
    class InstructionSet
    {

        public InstructionSet(string pathToInput)
        {
            string[] inputFile = File.ReadAllLines(pathToInput);

            foreach (string inputLine in inputFile)
            {
                if (inputLine.Trim().Length > 0) // Ignore blank lines
                    Add(inputLine);
            }
        }

        public double Result
        {
            get
            {
                return m_firstInstruction.Result;
            }
        }




        public Function GetFunctionFromLabel(int label)
        {
            Function requiredFunction = null;
            if (m_instructions.TryGetValue(label, out requiredFunction))
                return requiredFunction;

            throw new Exception("An instruction with the label '" + label + "' was not listed in the input file.");
        }


        public void CheckLabelForInfiniteLoop(int label)
        {
            if (m_labelsInProgress.Contains(label))
            {
                StringBuilder loopInfo = new StringBuilder(Environment.NewLine);
                foreach (int labelInProgress in m_labelsInProgress.ToArray().Reverse())
                {
                    loopInfo.Append(labelInProgress + Environment.NewLine);
                }
                loopInfo.Append(label + Environment.NewLine);

                throw new Exception("Infinite loop detected on label '" + label + "'.  " +
                    "The chain of labels that form the infinite loop are:" + loopInfo.ToString());
            }
            m_labelsInProgress.Push(label);
        }



        public void ClearInfiniteLoopCheck(int label)
        {
            m_labelsInProgress.Pop();
        }


        ////////////////



        private void Add(string inputLineToAdd)
        {
            try
            {
                string[] inputLineItems = inputLineToAdd.Split(new char[] { ':', ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);

                int label = int.Parse(inputLineItems[LabelIndex]);

                InstructionType instructionType = Enum.Parse<InstructionType>(inputLineItems[InstructionTypeIndex], true);

                List<int> parameters = new List<int>();

                int currentItemIndex = 0;
                foreach (string inputLineItem in inputLineItems)
                {
                    if (currentItemIndex >= ParameterStartIndex)
                        parameters.Add(int.Parse(inputLineItem));
                    currentItemIndex++;
                }

                if (parameters.Count == 0)
                    throw new Exception("Label '" + label + "' has no parameters");


                Function instructionToAdd = null;
                switch (instructionType)
                {
                    case InstructionType.Add:
                        instructionToAdd = new FunctionAdd(label, parameters, this);
                        break;
                    case InstructionType.Mult:
                        instructionToAdd = new FunctionMultiply(label, parameters, this);
                        break;
                    case InstructionType.Value:
                        instructionToAdd = new FunctionValue(label, parameters, this);
                        break;
                }

                if (m_firstInstruction == null)
                    m_firstInstruction = instructionToAdd;

                m_instructions.Add(instructionToAdd.Label, instructionToAdd);
            }
            catch (Exception err)
            {
                throw new Exception("Failed to parse the following line from the input file :-'" + inputLineToAdd + "'", err);
            }
        }


        private enum InstructionType { Add, Mult, Value }

        private Dictionary<int, Function> m_instructions = new Dictionary<int, Function>();

        private Stack<int> m_labelsInProgress = new Stack<int>();

        private Function m_firstInstruction = null;

        private const int LabelIndex = 0;
        private const int InstructionTypeIndex = 1;
        private const int ParameterStartIndex = 2;
    }
}
